local DEFAULT_DELAY = 16
local DEFAULT_SPEED = 3
local SPEED_FRAMES = {
  [1] = 14,
  [2] = 12,
  [3] = 10,
  [4] = 8,
  [5] = 6,
}
local DEFAULT_RATE = SPEED_FRAMES[DEFAULT_SPEED]

-- Gen 1 / Gen 2 screen ids and Gen 3 stack layer ids (src/ui/game3/stack.lua
-- push ids).  One table so denyScreen / allowScreen cover every generation.
local DENY_SCREEN_IDS = {
  -- Gen 1 / Gen 2
  SlotMachine = true,
  SurfingMinigame = true,
  BattleMoveSelect = true,
  BattleMoves = true,
  BattleFight = true,
  MoveSelect = true,
  UnownPuzzle = true,
  CardFlip = true,
  -- Gen 3: minigames
  slot_machine = true,
  rse_slot_machine = true,
  rse_roulette = true,
  rse_roulette_entry = true,
  rse_berry_blender = true,
  rs_berry_blender = true,
  rse_contest = true,
  rse_contest_results = true,
  whiteout_rush = true,
  -- Gen 3: scenes that read the D-pad as gameplay, not a cursor
  cable_car = true,
  rayquaza_scene = true,
  trade_scene = true,
  evolution_scene = true,
  egg_hatch = true,
  hall_of_fame = true,
  credits = true,
  rse_credits = true,
}

-- Gen 3 battle UI modes that are lists (src/core/game3/battle/ui.lua Ui._mode).
-- "menu" (FIGHT/BAG/POKEMON/RUN), "moves", "target" and "selmsg" stay off.
local GEN3_BATTLE_LIST_MODES = {
  bag = true,
  party = true,
}

-- Gen 3 boot (title-side) phases with a cursor menu (src/ui/game3/boot.lua).
local GEN3_BOOT_MENU_PHASES = {
  menu = true,
  mystery_gift = true,
  controls = true,
}

-- Cached runtime state (zero per-frame table lookups)
local cachedEnabled = true
local cachedDelay = DEFAULT_DELAY
local cachedSpeed = DEFAULT_SPEED
local cachedRate = DEFAULT_RATE

local function optNumber(mod, key, fallback, min, max)
  local v = mod.options and mod.options:get(key)
  local num = tonumber(v) or fallback
  num = math.floor(num + 0.5)
  if num < min then num = min end
  if num > max then num = max end
  return num
end

local function refreshOptions(mod)
  if not mod or not mod.options then return end
  local en = mod.options:get("enabled")
  cachedEnabled = (en ~= false and en ~= "false")
  cachedDelay = optNumber(mod, "initial_delay", DEFAULT_DELAY, 5, 60)
  cachedSpeed = optNumber(mod, "repeat_speed", DEFAULT_SPEED, 1, 5)
  cachedRate = SPEED_FRAMES[cachedSpeed] or DEFAULT_RATE
end

-- YES/NO and confirm prompts: Gen 3 menus name them in mode/state
-- ("yesno", "toss_confirm", "buy_confirm", "confirm", ...).  Several wrap on
-- Up/Down, so a held repeat would flip the answer back and forth.
local function isPromptState(v)
  return type(v) == "string" and (v == "yesno" or v:find("confirm", 1, true) ~= nil)
end

local function isYesNo(obj)
  if type(obj) ~= "table" then return false end
  return obj.kind == "yesno" or isPromptState(obj.mode) or isPromptState(obj.state)
end

local function optedOut(obj)
  return type(obj) == "table" and (obj.noDpadRepeat == true or obj.dpadRepeat == false)
end

-- ------- Gen 3 (FireRed / LeafGreen / Ruby / Sapphire / Emerald)
-- Game3 has no game.stack: its UI stack and battle UI are engine modules.  A
-- Gen 3 module required on a Gen 1/2 boot is refused by the loader, so every
-- lookup is gated on game.generation == 3 and goes through pcall.  The cache
-- is keyed to the live Game3 because ending a Gen 3 session drops the
-- engine's module caches and the next cartridge loads fresh tables.

local gen3Cache = {}
local gen3CacheOwner = nil

local function resetGen3Cache()
  gen3Cache = {}
  gen3CacheOwner = nil
end

local function isGen3(game)
  return type(game) == "table" and game.generation == 3
end

local function gen3Module(game, name)
  if gen3CacheOwner ~= game then
    gen3Cache = {}
    gen3CacheOwner = game
  end
  local m = gen3Cache[name]
  if m == nil then
    local ok, res = pcall(require, name)
    m = (ok and type(res) == "table") and res or false
    gen3Cache[name] = m
  end
  return m or nil
end

local function callBool(t, fname)
  local fn = t and t[fname]
  if type(fn) ~= "function" then return false end
  local ok, res = pcall(fn)
  return ok and res == true
end

local function gen3StackTop(game)
  local Stack = gen3Module(game, "src.ui.game3.stack")
  if not Stack or type(Stack.top) ~= "function" then return nil end
  local ok, layer = pcall(Stack.top)
  if ok and type(layer) == "table" then return layer end
  return nil
end

local function gen3BattleActive(game)
  local Battle = gen3Module(game, "src.core.game3.battle")
  return callBool(Battle, "isActive")
end

local function gen3PartyYesNo(game)
  return isYesNo(gen3Module(game, "src.ui.game3.party_menu"))
end

local function isGen3MenuContext(game)
  if game.phase == "arena" or game.phase == "quest_log" then return false end

  -- YES/NO overlay (src/ui/game3/choice.lua), field or battle
  local Choice = gen3Module(game, "src.ui.game3.choice")
  if Choice and callBool(Choice, "isOpen") and Choice.kind == "yesno" then
    return false
  end

  local MG = gen3Module(game, "src.core.game3.minigames.common")
  if callBool(MG, "isActive") then return false end

  local layer = gen3StackTop(game)
  if layer then
    if layer.id and DENY_SCREEN_IDS[layer.id] then return false end
    local menu = layer.mod
    if optedOut(layer) or optedOut(menu) then return false end
    if isYesNo(menu) then return false end
    return true
  end

  if gen3BattleActive(game) then
    local Ui = gen3Module(game, "src.core.game3.battle.ui")
    if not Ui then return false end
    if callBool(Ui, "yesNoPending") then return false end
    if not GEN3_BATTLE_LIST_MODES[Ui._mode] then return false end
    if Ui._mode == "party" and gen3PartyYesNo(game) then return false end
    return true
  end

  -- Open choice list with no layer under it (script multichoice)
  if Choice and callBool(Choice, "isOpen") then return true end

  if game.phase == "boot" then
    local boot = game.boot
    return type(boot) == "table" and GEN3_BOOT_MENU_PHASES[boot.phase] == true
  end

  -- field with nothing open is the overworld
  return false
end

-- ------- Gen 1 / Gen 2 (StateStack)

local function getStackTop(game)
  if type(game) ~= "table" then return nil end
  local stack = game.stack or (type(game.ui) == "table" and game.ui.stack)
  if type(stack) == "table" and type(stack.top) == "function" then
    local ok, top = pcall(stack.top, stack)
    if ok and type(top) == "table" then return top end
  end
  return nil
end

-- src/ui/ChoiceBox.lua, shared by Gen 1 and Gen 2: a two-row YES/NO box
local function isChoiceBoxYesNo(top)
  return top.onChoose ~= nil and type(top.labels) == "table" and #top.labels == 2
end

local function isStackMenuContext(game)
  local top = getStackTop(game)
  if not top then return false end
  if top.isOverworld then return false end
  if optedOut(top) then return false end
  if top.isMoveSelect or top.isBattleMoveSelect then return false end
  -- the battle state itself is the FIGHT/ITEM/PKMN/RUN box and move select;
  -- party and bag opened from battle are pushed above it and stay enabled
  if top.isBattle or top.isBattleState then return false end
  if isChoiceBoxYesNo(top) then return false end
  local id = top.screenId or top.id
  if id and DENY_SCREEN_IDS[id] then return false end
  return true
end

local function isMenuContext(game)
  if type(game) ~= "table" then return false end
  if isGen3(game) then return isGen3MenuContext(game) end
  return isStackMenuContext(game)
end

local function safeMenuContext(game)
  local ok, res = pcall(isMenuContext, game)
  return ok and res == true
end

local function ownsKeyRepeat(game)
  if isGen3(game) then return false end
  local top = getStackTop(game)
  return top ~= nil and top.keyRepeat == true
end

local function isDown(input, dir)
  local ok, down = pcall(input.isDown, input, dir)
  return ok and down == true
end

local function heldDir(input)
  local up = isDown(input, "up")
  local down = isDown(input, "down")
  if up and not down then return "up" end
  if down and not up then return "down" end
  local left = isDown(input, "left")
  local right = isDown(input, "right")
  if left and not right then return "left" end
  if right and not left then return "right" end
  return nil
end

local function injectInputPress(input, dir)
  if type(input.press) == "function" then
    pcall(input.press, input, dir)
  elseif type(input.injectPress) == "function" then
    pcall(input.injectPress, input, dir)
  elseif type(input.pressQueue) == "table" then
    input.pressQueue[#input.pressQueue + 1] = dir
  end
end

return function(mod)
  mod.options:define({
    {
      key = "enabled",
      type = "toggle",
      label = "AUTO SCROLL",
      default = true,
    },
    {
      key = "initial_delay",
      type = "number",
      label = "HOLD DELAY",
      default = DEFAULT_DELAY,
      min = 5,
      max = 60,
      step = 1,
    },
    {
      key = "repeat_speed",
      type = "choice",
      label = "REPEAT SPEED",
      default = DEFAULT_SPEED,
      choices = {
        { "1", 1 },
        { "2", 2 },
        { "3", 3 },
        { "4", 4 },
        { "5", 5 },
      },
    },
  })

  refreshOptions(mod)

  mod.exports.isMenuContext = safeMenuContext
  mod.exports.denyScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = true end
  end
  mod.exports.allowScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = nil end
  end
  mod.exports.defaults = {
    initialDelay = DEFAULT_DELAY,
    repeatSpeed = DEFAULT_SPEED,
    repeatRate = DEFAULT_RATE,
    speedFrames = SPEED_FRAMES,
  }

  -- Gen 1 / Gen 2 ListMenu; Gen 3's list menu does not fire this hook and is
  -- covered by input.step below
  mod.hooks:wrap("ui.list_menu", function(next, opts, ctx)
    opts = next(opts, ctx) or opts
    if not cachedEnabled then return opts end
    if type(opts) ~= "table" then return opts end
    if optedOut(opts) then return opts end

    local id = opts.screenId or (ctx and ctx.screenId)
    if id and DENY_SCREEN_IDS[id] then return opts end
    if opts.isMoveSelect or opts.isBattleMoveSelect or (ctx and (ctx.isMoveSelect or ctx.isBattleMoveSelect)) then
      return opts
    end

    opts.keyRepeat = true
    opts.repeatDelay = cachedDelay
    opts.repeatRate = cachedRate
    return opts
  end)

  local holdDirState = nil
  local holdFrames = 0
  local holdDelay = DEFAULT_DELAY
  local holdRate = DEFAULT_RATE

  local function resetHold()
    holdDirState, holdFrames = nil, 0
    holdDelay, holdRate = cachedDelay, cachedRate
  end

  mod.hooks:wrap("input.step", function(nextFn, game, dt)
    -- Fast Exit 1: Master toggle disabled
    if not cachedEnabled then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    local input = type(game) == "table" and game.input
    if type(input) ~= "table" or type(input.isDown) ~= "function" then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    -- Fast Exit 2: No D-pad held (skips stack lookups entirely)
    local dir = heldDir(input)
    if not dir then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    -- Only inspect menu context if a button is actually held down
    if not safeMenuContext(game) then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    if ownsKeyRepeat(game) then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    if dir ~= holdDirState then
      holdDirState = dir
      holdFrames = 0
      holdDelay = cachedDelay
      holdRate = cachedRate
    end

    -- Gen 3 menus run their own 40/5-frame repeat off the held key; each
    -- synthetic press reads as a fresh edge and restarts that count, so only
    -- this cadence fires and nothing double-steps.
    holdFrames = holdFrames + 1
    local afterDelay = holdFrames - holdDelay
    if holdFrames > 1 and afterDelay >= 0 and afterDelay % holdRate == 0 then
      injectInputPress(input, dir)
    end

    return nextFn(game, dt)
  end)

  mod.events:on("mod.options_changed", function(ev)
    if not ev or ev.mod ~= mod.id then return end
    refreshOptions(mod)
  end)

  mod.events:on("game.ready", function()
    resetGen3Cache()
    resetHold()
  end)

  mod.events:on("save.loaded", function()
    refreshOptions(mod)
  end)

  mod.log:info("hold D-pad in menus to auto-repeat (cached delay=%d rate=%d)",
    cachedDelay, cachedRate)
end
