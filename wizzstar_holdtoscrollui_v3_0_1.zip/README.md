# G123R HoldToScrollUI Mod

Hold any **D-pad** direction in menus to auto-repeat after a short delay — lists, option rows, and value steppers. Supports **Gen1Recomp** (Red, Blue, Yellow), **Gen2Recomp** (Gold, Silver, Crystal) and **Gen 3** (FireRed, LeafGreen, Ruby, Sapphire, Emerald).

## Persona

Small accessibility / QoL input helper for Gen 1, Gen 2 & Gen 3 Recompilation project menus.

## Try it

1. Enable **G123R HoldToScrollUI Mod** in the mod manager.
2. Open the Start menu, bag, party, PC, Pokédex, options, or any other menu.
3. Hold **Down** / **Up** to scroll lists, or **Left** / **Right** to step option values — after a brief pause it keeps repeating.
4. Walk around in the overworld — hold does **not** auto-walk; only menus repeat.
5. Tweak **HOLD DELAY** and **REPEAT SPEED** under the mod’s options.

## Defaults

| Option | Default | Meaning |
|---|---|---|
| AUTO SCROLL | ON | Master enable |
| HOLD DELAY | 16 | Frames before the first repeat (~267 ms) |
| REPEAT SPEED | **3** | Middle of a 1–5 ladder (see below) |

### REPEAT SPEED ladder

| Setting | Feel | Frames between repeats |
|---|---|---|
| 1 | Slightly slower | 14 |
| 2 | Slightly slower | 12 |
| **3** | **Default** (the tuned feel) | **10** |
| 4 | Slightly faster | 8 |
| 5 | Fastest | 6 |

## How it stays modular for other mods

| Path | Hook | Covers |
|---|---|---|
| Native list hold-scroll | `ui.list_menu` | Gen 1/2: bag, shops, PC item lists, Pokédex lists, any mod `ListMenu` |
| Synthetic edges | `input.step` | Every generation: Start menu, party, options, battle bag/party, custom mod screens that call `input:wasPressed` |

So a brand-new menu from another mod usually just works if it uses the shared input API — no per-menu registration required.

### Gen 3 notes

Gen 3 has no `game.stack`, so the mod reads the Gen 3 UI stack (`src/ui/game3/stack.lua`) and battle UI directly. It only loads those modules on a Gen 3 boot, through `pcall`. Gen 3 lists that already repeat on their own (40-frame delay, 5-frame rate) switch to your HOLD DELAY / REPEAT SPEED: each synthetic press restarts the game's own counter, so the two never double-step.

### Always suppressed

* Overworld movement
* Battle command box (FIGHT / BAG / POKéMON / RUN), move select and target select — every generation
* YES / NO and confirm prompts (toss / buy confirms, battle switch prompts, etc.)
* Slot Machine, Roulette, Berry Blender, Contests, Surfing Minigame, Unown Puzzle, Card Flip

### Opt out (for UI authors)

On your screen object (Gen 1/2) or the module you `Stack.push` (Gen 3), set either:

```lua
state.noDpadRepeat = true
-- or
state.dpadRepeat = false
```

Or from another mod: `exports.denyScreen("my_screen_id")` / `exports.allowScreen(id)`. Gen 3 uses the stack layer id.
